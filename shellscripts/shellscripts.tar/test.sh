#!/bin/sh


now=$(date)
echo "$now"
